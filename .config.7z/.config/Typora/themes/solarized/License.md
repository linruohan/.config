## License

Typora-Solarized theme was created by [Rafael Belenos](https://github.com/belenos) and distributed under The GNU General Public License v3.0. You can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.



#### Mononoki
This theme uses Mononoki, an open source monospace font for programming and code review developed for high and low resolution displays. For more details and how to download the complete files, go to the [official repository](https://github.com/madmalik/mononoki).